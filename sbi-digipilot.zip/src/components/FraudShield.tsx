import React, { useState } from "react";
import { ShieldAlert, CheckCircle, HelpCircle, Sparkles, Send, FileText, AlertTriangle, ArrowRight } from "lucide-react";
import { FraudAnalysis } from "../types";

const SCAM_PRESETS = [
  {
    title: "Electricity Bill Scam SMS",
    text: "Dear customer your Electricity power will be disconnected tonight 9:30 PM from office. Immediately call officer Sharma at 98765-XXXXX. Please pay pending bill or install support app."
  },
  {
    title: "KYC Account Block Alert",
    text: "SBI ALERT: Dear customer your SBI Netbanking YONO account has been suspended today. Please click https://sbi-kyc-verify-portal.web.app to update your PAN Card immediately to avoid block."
  },
  {
    title: "Telegram Part-Time Job Opportunity",
    text: "Earn ₹3000 to ₹8000 daily working from home! Simply like YouTube videos and review products. No experience needed. Join our Telegram group t.me/sbi-easy-tasks-now to claim your ₹500 welcome bonus!"
  }
];

export default function FraudShield() {
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [analysis, setAnalysis] = useState<FraudAnalysis | null>(null);

  const handlePresetSelect = (text: string) => {
    setInputText(text);
    setAnalysis(null);
  };

  const handleAnalyze = async () => {
    if (!inputText.trim()) {
      alert("Please enter or paste message content first.");
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch("/api/agents/check-fraud", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: inputText })
      });
      const data = await response.json();
      setAnalysis(data);
    } catch (err) {
      console.error("Error analyzing text for scams:", err);
      alert("An error occurred during safety verification. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div id="fraud-shield" className="p-6 max-w-6xl mx-auto space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-rose-955 via-red-900 to-rose-900 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden border border-rose-800">
        <div className="absolute right-0 top-0 opacity-10 pointer-events-none transform translate-x-12 -translate-y-12">
          <ShieldAlert size={300} />
        </div>
        <div className="max-w-2xl space-y-4">
          <span className="bg-rose-500/30 text-rose-200 text-xs font-bold tracking-widest uppercase px-3.5 py-1.5 rounded-full border border-rose-400/20 inline-flex items-center gap-1.5">
            <Sparkles size={12} /> Proactive Cyber Shield
          </span>
          <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">
            SBI Fraud Protection & Scam Analysis Desk
          </h1>
          <p className="text-rose-100 text-sm md:text-base leading-relaxed">
            Suspicious SMS? Unverified WhatsApp link? Drop or copy-paste suspicious text patterns below. Our AI Security Guard scans the grammar, threat vectors, links, and urgent language to alert you.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Input area & presets (2 Columns) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-6 space-y-5">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Analyze Suspicious Message</h3>
                <p className="text-xs text-slate-500">Copy the full content, link, or phone number you received.</p>
              </div>
              <button
                onClick={() => setInputText("")}
                className="text-xs text-slate-400 hover:text-slate-650 font-semibold"
              >
                Clear Field
              </button>
            </div>

            <textarea
              id="fraud-message-input"
              rows={5}
              placeholder="Paste suspicious SMS, WhatsApp message, email, lottery offer, or website link here..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm outline-none focus:bg-white focus:ring-2 focus:ring-rose-500 transition-all text-slate-800"
            />

            <button
              id="btn-analyze-fraud"
              onClick={handleAnalyze}
              disabled={isLoading}
              className={`w-full py-4 rounded-2xl font-bold text-sm transition-all shadow-sm flex items-center justify-center gap-2 ${
                isLoading
                  ? "bg-rose-100 text-rose-400 cursor-not-allowed"
                  : "bg-rose-600 hover:bg-rose-700 text-white"
              }`}
            >
              {isLoading ? "Running Security Audit..." : "Analyze Message & Assess Risk"}
              <Send size={15} />
            </button>
          </div>

          {/* Quick presets cards */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Try Common Scam Templates</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {SCAM_PRESETS.map((p, idx) => (
                <button
                  key={idx}
                  id={`preset-scam-${idx}`}
                  onClick={() => handlePresetSelect(p.text)}
                  className="p-4 bg-slate-50 hover:bg-rose-50 hover:border-rose-200 border border-slate-100 rounded-2xl text-left transition-all space-y-1.5 cursor-pointer group"
                >
                  <span className="text-xs font-bold text-slate-800 group-hover:text-rose-900 truncate block">
                    {p.title}
                  </span>
                  <p className="text-[10px] text-slate-500 line-clamp-3 group-hover:text-rose-800">
                    "{p.text}"
                  </p>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Security guard analysis report (1 Column) */}
        <div>
          {analysis ? (
            <div className={`bg-white rounded-3xl border shadow-md p-6 space-y-6 transition-all ${
              analysis.riskLevel === "danger"
                ? "border-red-200 ring-4 ring-red-500/5"
                : analysis.riskLevel === "warning"
                ? "border-amber-200 ring-4 ring-amber-500/5"
                : "border-emerald-200 ring-4 ring-emerald-500/5"
            }`}>
              {/* Threat Status indicator */}
              <div className="text-center space-y-2">
                <div className={`w-14 h-14 rounded-full flex items-center justify-center mx-auto shadow-sm ${
                  analysis.riskLevel === "danger"
                    ? "bg-red-100 text-red-600"
                    : analysis.riskLevel === "warning"
                    ? "bg-amber-100 text-amber-600"
                    : "bg-emerald-100 text-emerald-600"
                }`}>
                  {analysis.riskLevel === "danger" ? <ShieldAlert size={28} /> : <CheckCircle size={28} />}
                </div>
                <div>
                  <h3 className="text-lg font-black tracking-tight text-slate-900">
                    {analysis.scamType || "Safety Verdict"}
                  </h3>
                  <span className={`text-[10px] font-black tracking-widest uppercase px-3 py-1 rounded-full ${
                    analysis.riskLevel === "danger"
                      ? "bg-red-100 text-red-800"
                      : analysis.riskLevel === "warning"
                      ? "bg-amber-100 text-amber-800"
                      : "bg-emerald-100 text-emerald-800"
                  }`}>
                    {analysis.riskLevel.toUpperCase()} RISK • {analysis.confidence}% CONFIDENCE
                  </span>
                </div>
              </div>

              {/* Red Flags detected */}
              <div className="space-y-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Red Flags Found</span>
                <div className="space-y-1.5">
                  {analysis.indicators.map((ind, idx) => (
                    <div key={idx} className="flex gap-2 items-start text-xs text-slate-600">
                      <AlertTriangle className="text-amber-500 shrink-0 mt-0.5" size={14} />
                      <p>{ind}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Protective explanation */}
              <div className="space-y-1 bg-slate-50 rounded-2xl p-4 border border-slate-100 text-xs">
                <span className="font-bold text-slate-400 uppercase text-[10px] tracking-wider block">Detailed Assessment</span>
                <p className="text-slate-600 leading-relaxed">{analysis.explanation}</p>
              </div>

              {/* Action checklist */}
              <div className="space-y-2.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Your Action Plan</span>
                <div className="space-y-2">
                  {analysis.safetyChecklist.map((step, idx) => (
                    <div key={idx} className="flex gap-2.5 items-start text-xs text-slate-700 leading-relaxed font-semibold">
                      <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-700 flex items-center justify-center text-[10px] shrink-0 font-bold">
                        {idx + 1}
                      </span>
                      <p>{step}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-50 rounded-3xl p-8 border border-slate-200 text-center space-y-4 h-full flex flex-col justify-center min-h-[350px]">
              <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 mx-auto">
                <FileText size={22} />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-800">Waiting for text content</h4>
                <p className="text-xs text-slate-500 leading-relaxed max-w-xs mx-auto mt-1">
                  Enter suspicious texts, phishing alerts, or unverified work offers on the left. Hit "Analyze Message" to generate an interactive AI cyber report.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
