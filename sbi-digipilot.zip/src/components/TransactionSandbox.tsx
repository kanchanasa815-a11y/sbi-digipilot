import React, { useState } from "react";
import { ArrowRight, ShieldAlert, Sparkles, CheckCircle2, QrCode, CreditCard, RefreshCw, Smartphone, HelpCircle } from "lucide-react";

interface SandboxHistory {
  id: string;
  type: "UPI" | "IMPS" | "Bill Pay";
  amount: number;
  recipient: string;
  status: "Success" | "Blocked" | "Warning Accepted";
  date: string;
}

export default function TransactionSandbox() {
  const [txType, setTxType] = useState<"upi" | "imps" | "bill">("upi");
  const [recipientVpa, setRecipientVpa] = useState("");
  const [recipientAccount, setRecipientAccount] = useState("");
  const [recipientIfsc, setRecipientIfsc] = useState("");
  const [billerName, setBillerName] = useState("State Electricity Distribution");
  const [amount, setAmount] = useState<number>(0);
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1); // 1: Input, 2: Agent Audit, 3: PIN entry, 4: Success
  const [upiPin, setUpiPin] = useState("");
  const [pinError, setPinError] = useState("");
  
  // Real-time Agent assessment values
  const [isSuspicious, setIsSuspicious] = useState(false);
  const [alertReason, setAlertReason] = useState("");
  const [agentLogs, setAgentLogs] = useState<{ agent: string; msg: string; type: "info" | "success" | "warn" }[]>([]);
  const [history, setHistory] = useState<SandboxHistory[]>([
    { id: "TX1001", type: "UPI", amount: 1500, recipient: "Ramesh Kumar (Grocery)", status: "Success", date: "Today, 10:15 AM" },
    { id: "TX1002", type: "Bill Pay", amount: 2450, recipient: "SBI Credit Card Bill", status: "Success", date: "Yesterday, 4:30 PM" }
  ]);

  // Quick preset destinations
  const handleQuickPreset = (vpa: string, alertType: boolean, reason: string) => {
    setRecipientVpa(vpa);
    setIsSuspicious(alertType);
    setAlertReason(reason);
    setStep(1);
  };

  const startVerification = () => {
    if (txType === "upi" && !recipientVpa.includes("@")) {
      alert("Please enter a valid VPA (e.g. username@sbi or username@upi)");
      return;
    }
    if (txType === "imps" && (!recipientAccount || !recipientIfsc)) {
      alert("Please enter both account number and IFSC code");
      return;
    }
    if (amount <= 0) {
      alert("Please enter a valid transfer amount greater than ₹0");
      return;
    }

    // Move to step 2: Agent Audit
    setStep(2);
    setAgentLogs([
      { agent: "Coordinator Agent", msg: "Initiating sandbox transaction routing check...", type: "info" },
      { agent: "Transaction Agent", msg: `Validating target recipient: ${txType === "upi" ? recipientVpa : recipientAccount}`, type: "info" }
    ]);

    // Simulate Agent checks sequentially
    setTimeout(() => {
      if (isSuspicious || recipientVpa === "win-prize-now@upi" || recipientVpa.toLowerCase().includes("win") || recipientVpa.toLowerCase().includes("lottery")) {
        setIsSuspicious(true);
        setAlertReason("Recipient address has been reported multiple times for lottery & advance-fee scams. Highly risky.");
        setAgentLogs(prev => [
          ...prev,
          { agent: "Fraud Protection Agent", msg: "CRITICAL ALERT: Target address matches active financial scam database!", type: "warn" },
          { agent: "Learning Agent", msg: "Educational advice: Genuine entities or banks never ask you to pay processing fees via UPI to unlock prizes.", type: "info" }
        ]);
      } else {
        setAgentLogs(prev => [
          ...prev,
          { agent: "Fraud Protection Agent", msg: "Address cleared. No malicious reports or unusual speed-velocity patterns found.", type: "success" },
          { agent: "Wellness Agent", msg: `Recommending transaction authorization. This falls within your weekly budget.`, type: "success" }
        ]);
      }
    }, 1000);
  };

  const handlePinConfirm = () => {
    if (upiPin.length !== 6 || isNaN(Number(upiPin))) {
      setPinError("UPI PIN must be exactly 6 digits.");
      return;
    }
    setPinError("");
    setStep(4);
    
    // Add to simulated history
    const targetName = txType === "upi" ? recipientVpa : txType === "imps" ? `A/C ${recipientAccount}` : billerName;
    const newTx: SandboxHistory = {
      id: "TX" + Math.floor(1000 + Math.random() * 9000),
      type: txType === "upi" ? "UPI" : txType === "imps" ? "IMPS" : "Bill Pay",
      amount,
      recipient: targetName,
      status: isSuspicious ? "Warning Accepted" : "Success",
      date: "Just now"
    };
    setHistory(prev => [newTx, ...prev]);
  };

  const resetSandbox = () => {
    setRecipientVpa("");
    setRecipientAccount("");
    setRecipientIfsc("");
    setAmount(0);
    setUpiPin("");
    setStep(1);
    setIsSuspicious(false);
    setAlertReason("");
    setPinError("");
  };

  return (
    <div id="transaction-sandbox" className="p-6 max-w-6xl mx-auto space-y-6">
      {/* Overview Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-teal-900 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden border border-emerald-800">
        <div className="absolute right-0 top-0 opacity-10 pointer-events-none transform translate-x-12 -translate-y-12">
          <Smartphone size={300} />
        </div>
        <div className="max-w-2xl space-y-4">
          <span className="bg-emerald-500/30 text-emerald-200 text-xs font-bold tracking-widest uppercase px-3.5 py-1.5 rounded-full border border-emerald-400/20 inline-flex items-center gap-1.5">
            <Sparkles size={12} /> Secure Practice Sandbox
          </span>
          <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">
            SBI Digital Transaction Simulator
          </h1>
          <p className="text-emerald-100 text-sm md:text-base leading-relaxed">
            Practice digital payments with **zero real money risk**. Test real-life transaction flows, learn the difference between UPI, NEFT, IMPS, and see how our Fraud Agent watches your back.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Step Simulator Workstation (Left & Middle Column) */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-100 shadow-sm p-6 flex flex-col justify-between min-h-[500px]">
          {/* Header */}
          <div className="border-b border-slate-100 pb-4 mb-6 flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Sandbox Playground</h2>
              <p className="text-xs text-slate-500">Practice safely. No real balance will be deducted.</p>
            </div>
            {/* Step Progress indicators */}
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4].map((s) => (
                <div
                  key={s}
                  className={`w-8 h-2 rounded-full transition-all ${
                    step >= s ? "bg-emerald-600" : "bg-slate-100"
                  }`}
                  title={`Step ${s}`}
                />
              ))}
            </div>
          </div>

          {/* Core Simulator Stage */}
          <div className="flex-1 flex flex-col justify-center">
            {step === 1 && (
              <div className="space-y-6">
                {/* Method selector */}
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => { setTxType("upi"); resetSandbox(); }}
                    className={`py-3 px-4 rounded-xl font-semibold text-xs flex flex-col items-center gap-2 border transition-all ${
                      txType === "upi"
                        ? "bg-emerald-50 border-emerald-200 text-emerald-900 shadow-sm"
                        : "bg-slate-50 border-slate-100 text-slate-600 hover:bg-slate-100"
                    }`}
                  >
                    <QrCode size={18} />
                    <span>BHIM UPI Pay</span>
                  </button>
                  <button
                    onClick={() => { setTxType("imps"); resetSandbox(); }}
                    className={`py-3 px-4 rounded-xl font-semibold text-xs flex flex-col items-center gap-2 border transition-all ${
                      txType === "imps"
                        ? "bg-emerald-50 border-emerald-200 text-emerald-900 shadow-sm"
                        : "bg-slate-50 border-slate-100 text-slate-600 hover:bg-slate-100"
                    }`}
                  >
                    <ArrowRight size={18} />
                    <span>IMPS (Account Transfer)</span>
                  </button>
                  <button
                    onClick={() => { setTxType("bill"); resetSandbox(); }}
                    className={`py-3 px-4 rounded-xl font-semibold text-xs flex flex-col items-center gap-2 border transition-all ${
                      txType === "bill"
                        ? "bg-emerald-50 border-emerald-200 text-emerald-900 shadow-sm"
                        : "bg-slate-50 border-slate-100 text-slate-600 hover:bg-slate-100"
                    }`}
                  >
                    <CreditCard size={18} />
                    <span>Bill Payment</span>
                  </button>
                </div>

                {/* Form fields based on selection */}
                <div className="space-y-4">
                  {txType === "upi" && (
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-700 block">Recipient UPI ID (VPA)</label>
                      <input
                        id="sandbox-vpa"
                        type="text"
                        placeholder="e.g. ram@sbi or kbc-winner@upi"
                        value={recipientVpa}
                        onChange={(e) => setRecipientVpa(e.target.value)}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white text-sm outline-none text-slate-800"
                      />
                      {/* Presets */}
                      <div className="flex gap-1.5 flex-wrap items-center mt-2">
                        <span className="text-[10px] text-slate-400 font-bold uppercase mr-1">Quick Scenarios:</span>
                        <button
                          onClick={() => handleQuickPreset("family.member@sbi", false, "")}
                          className="px-2.5 py-1 text-[10px] bg-slate-100 text-slate-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg font-medium transition-all"
                        >
                          Send to Son (Safe)
                        </button>
                        <button
                          onClick={() => handleQuickPreset("kbc-lottery-tax@upi", true, "Lottery Processing Fee scam detected.")}
                          className="px-2.5 py-1 text-[10px] bg-red-50 text-red-700 hover:bg-red-100 rounded-lg font-medium transition-all flex items-center gap-1"
                        >
                          <ShieldAlert size={10} /> Lottery Winner Tax (Scam)
                        </button>
                        <button
                          onClick={() => handleQuickPreset("unknown-billing@upi", true, "This is a suspicious business QR code scanning scenario.")}
                          className="px-2.5 py-1 text-[10px] bg-amber-50 text-amber-700 hover:bg-amber-100 rounded-lg font-medium transition-all"
                        >
                          Unverified QR Scan
                        </button>
                      </div>
                    </div>
                  )}

                  {txType === "imps" && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-700 block">Beneficiary Account Number</label>
                        <input
                          id="sandbox-account"
                          type="text"
                          placeholder="e.g. 30948573902"
                          value={recipientAccount}
                          onChange={(e) => setRecipientAccount(e.target.value)}
                          className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none text-slate-800"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-700 block">IFSC Code</label>
                        <input
                          id="sandbox-ifsc"
                          type="text"
                          placeholder="e.g. SBIN0001234"
                          value={recipientIfsc}
                          onChange={(e) => setRecipientIfsc(e.target.value)}
                          className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none text-slate-800"
                        />
                      </div>
                    </div>
                  )}

                  {txType === "bill" && (
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-700 block">Choose Biller Category</label>
                        <select
                          value={billerName}
                          onChange={(e) => setBillerName(e.target.value)}
                          className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none text-slate-800"
                        >
                          <option value="State Electricity Board">Electricity Bill (APDCL/MSEB/UPPCL)</option>
                          <option value="Water Supply Corporation">Water Board Bill</option>
                          <option value="SBI Life Insurance Premium">SBI Life Insurance Premium</option>
                        </select>
                      </div>
                    </div>
                  )}

                  {/* Amount input */}
                  <div className="space-y-2 pt-2">
                    <label className="text-xs font-bold text-slate-700 block">Amount to Practice Transfer (₹)</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-lg">₹</span>
                      <input
                        id="sandbox-amount"
                        type="number"
                        placeholder="Enter amount (e.g. 500)"
                        value={amount || ""}
                        onChange={(e) => setAmount(Number(e.target.value))}
                        className="w-full pl-8 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white text-lg font-bold text-slate-800 outline-none"
                      />
                    </div>
                  </div>
                </div>

                <button
                  id="btn-sandbox-verify"
                  onClick={startVerification}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-4 rounded-2xl font-bold transition-all shadow-sm flex items-center justify-center gap-2"
                >
                  Verify Recipient & Continue <ArrowRight size={16} />
                </button>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 space-y-4">
                  <h3 className="text-sm font-bold text-slate-900 tracking-tight uppercase flex items-center gap-2">
                    <RefreshCw className="animate-spin text-blue-600" size={16} /> Cyber Shield Safety Audit
                  </h3>
                  
                  <div className="space-y-2">
                    {agentLogs.map((log, idx) => (
                      <div
                        key={idx}
                        className={`text-xs p-3 rounded-lg border leading-relaxed ${
                          log.type === "warn"
                            ? "bg-red-50 border-red-200 text-red-800"
                            : log.type === "success"
                            ? "bg-emerald-50 border-emerald-200 text-emerald-800"
                            : "bg-blue-50 border-blue-200 text-blue-800"
                        }`}
                      >
                        <span className="font-bold">{log.agent}:</span> {log.msg}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Scenario Warning Trigger */}
                {isSuspicious ? (
                  <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 space-y-3">
                    <div className="flex gap-2 text-amber-800">
                      <ShieldAlert className="shrink-0" size={20} />
                      <div>
                        <h4 className="text-sm font-extrabold uppercase">Potential Security Scam Warning!</h4>
                        <p className="text-xs mt-1 leading-relaxed">
                          {alertReason || "This recipient address is flagged for suspicious activities. Cyber criminals commonly trick users into scanning unknown codes."}
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setStep(3)}
                        className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl transition-all"
                      >
                        Ignore & Proceed (Risky)
                      </button>
                      <button
                        onClick={resetSandbox}
                        className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl transition-all"
                      >
                        Cancel Transaction (Safe Choice)
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <p className="text-sm text-slate-600 leading-relaxed">
                      Our multi-agent guards did not find any cyber fraud records for this recipient. You can proceed with the transaction.
                    </p>
                    <button
                      onClick={() => setStep(3)}
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-4 rounded-2xl font-bold transition-all shadow-sm"
                    >
                      Authorize Transaction
                    </button>
                  </div>
                )}
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6 max-w-sm mx-auto text-center">
                <div className="p-4 bg-blue-50 text-blue-700 rounded-2xl inline-flex items-center gap-2 mb-2 border border-blue-100">
                  <Smartphone size={18} />
                  <span className="text-xs font-bold uppercase tracking-wider">Practice Security Keyboard</span>
                </div>
                
                <h3 className="text-lg font-bold text-slate-900">Enter 6-Digit UPI PIN</h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  In a real transaction, you enter this code on the secure SBI gateway. For this practice session, enter **any 6-digit number** (e.g., 123456) below.
                </p>

                <div className="space-y-2">
                  <input
                    id="sandbox-pin"
                    type="password"
                    maxLength={6}
                    placeholder="••••••"
                    value={upiPin}
                    onChange={(e) => setUpiPin(e.target.value)}
                    className="w-full text-center py-3 bg-slate-100 border border-slate-200 rounded-xl text-2xl font-bold tracking-widest focus:bg-white outline-none text-slate-800"
                  />
                  {pinError && <p className="text-xs text-red-600 font-semibold">{pinError}</p>}
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button
                    onClick={() => setStep(1)}
                    className="py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all"
                  >
                    Go Back
                  </button>
                  <button
                    onClick={handlePinConfirm}
                    className="py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm"
                  >
                    Submit Secure PIN
                  </button>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="text-center py-8 space-y-6 max-w-md mx-auto">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
                  <CheckCircle2 size={36} />
                </div>
                
                <div>
                  <h3 className="text-2xl font-extrabold text-slate-900">Practice Transfer Successful!</h3>
                  <p className="text-sm text-emerald-700 font-medium mt-1">₹{amount} successfully simulated.</p>
                  <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                    Great job! You have successfully practiced completing a digital transfer. You handled verification steps, analyzed risk, and securely keyed in simulated credentials.
                  </p>
                </div>

                <div className="p-4 bg-slate-50 rounded-2xl text-left border border-slate-100 space-y-2 text-xs">
                  <span className="font-bold uppercase text-slate-400 text-[10px] tracking-wider block">Receipt Details</span>
                  <div className="flex justify-between text-slate-700">
                    <span>Transaction Type:</span>
                    <span className="font-semibold">{txType.toUpperCase()} Transfer</span>
                  </div>
                  <div className="flex justify-between text-slate-700">
                    <span>Recipient VPA:</span>
                    <span className="font-semibold truncate max-w-xs">{recipientVpa || recipientAccount || billerName}</span>
                  </div>
                  <div className="flex justify-between text-slate-700">
                    <span>Safety Score:</span>
                    <span className="font-bold text-emerald-600">100/100 Perfect Practice</span>
                  </div>
                </div>

                <button
                  onClick={resetSandbox}
                  className="w-full bg-slate-950 hover:bg-slate-850 text-white py-3.5 rounded-2xl text-sm font-bold transition-all"
                >
                  Start Another Practice Session
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Practice Analytics & Log (Right Column) */}
        <div className="space-y-6">
          <div className="bg-slate-50 rounded-3xl p-6 border border-slate-100 space-y-4">
            <h3 className="text-xs font-extrabold uppercase tracking-widest text-slate-400">Sandbox Guidelines</h3>
            
            <div className="space-y-3.5">
              <div className="flex gap-2.5 items-start text-xs leading-relaxed text-slate-600">
                <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 font-bold flex items-center justify-center text-[10px] shrink-0">1</div>
                <div>
                  <h4 className="font-bold text-slate-900">Verify Identity First</h4>
                  <p>In digital transactions, checking the recipient's name or VPA helps prevent sending money to the wrong person.</p>
                </div>
              </div>

              <div className="flex gap-2.5 items-start text-xs leading-relaxed text-slate-600">
                <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 font-bold flex items-center justify-center text-[10px] shrink-0">2</div>
                <div>
                  <h4 className="font-bold text-slate-900">PIN safety</h4>
                  <p>Your 6-digit UPI PIN is highly confidential. No bank, official, or customer service representative will ever ask for this code.</p>
                </div>
              </div>

              <div className="flex gap-2.5 items-start text-xs leading-relaxed text-slate-600">
                <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 font-bold flex items-center justify-center text-[10px] shrink-0">3</div>
                <div>
                  <h4 className="font-bold text-slate-900">Recieving is FREE</h4>
                  <p>Never key in your UPI PIN to receive funds. If a sender tells you to input your PIN to 'accept' cash, they are scamming you.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Sandbox practice history */}
          <div className="bg-white rounded-3xl p-6 border border-slate-100 space-y-4">
            <h3 className="text-xs font-extrabold uppercase tracking-widest text-slate-400">Practice History</h3>
            
            <div className="space-y-2.5 max-h-[220px] overflow-y-auto pr-1">
              {history.map((tx) => (
                <div
                  key={tx.id}
                  className="p-3 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-100 flex items-center justify-between text-xs transition-all"
                >
                  <div className="space-y-0.5">
                    <span className="font-bold text-slate-900 block truncate max-w-[150px]">{tx.recipient}</span>
                    <span className="text-[10px] text-slate-400">{tx.type} • {tx.date}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-slate-900 block">₹{tx.amount}</span>
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold uppercase tracking-wider inline-block mt-0.5 ${
                        tx.status === "Success"
                          ? "bg-emerald-100 text-emerald-800"
                          : "bg-amber-100 text-amber-800"
                      }`}
                    >
                      {tx.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
