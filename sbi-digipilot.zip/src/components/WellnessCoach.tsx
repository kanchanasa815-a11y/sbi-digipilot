import React, { useState } from "react";
import { TrendingUp, ShieldCheck, Sparkles, PiggyBank, Award, ArrowUpRight, HelpCircle, CheckCircle2 } from "lucide-react";
import { SBIProduct } from "../types";

const SBI_PRODUCTS: SBIProduct[] = [
  {
    id: "amrit-kalash",
    name: "SBI Amrit Kalash scheme (400 Days)",
    tag: "Fixed Deposit",
    description: "Highly secure term deposit offering top-tier returns for a specific tenure of 400 days. Perfect for parking idle savings safely.",
    interestRate: "7.10%",
    minAmount: 10000,
    duration: "400 Days",
    benefits: [
      "Special higher interest rate of 7.10% (7.60% for Senior Citizens)",
      "Loan facility available against deposit",
      "Instant online activation via SBI YONO"
    ]
  },
  {
    id: "flexi-rd",
    name: "SBI Flexi Recurring Deposit (RD)",
    tag: "Flexible Savings",
    description: "A recurring deposit where instead of a fixed monthly sum, you can deposit flexible amounts anytime based on your pocket budget.",
    interestRate: "6.80%",
    minAmount: 500,
    duration: "1 to 5 Years",
    benefits: [
      "Minimum deposit of just ₹500 per installment",
      "Deposit multiple times in a single month",
      "Auto-debit setup available from savings account"
    ]
  },
  {
    id: "sip-mutual",
    name: "SBI Mutual Fund SIP (Systematic Investment Plan)",
    tag: "Wealth Creation",
    description: "Invest small sums regularly in highly rated SBI Mutual Funds. Harnesses market compounding to build long-term wealth.",
    interestRate: "12.0% (Est)",
    minAmount: 100,
    duration: "Flexible",
    benefits: [
      "Start investing with as little as ₹100 per month",
      "Rupee cost averaging protects against market dips",
      "Easily monitor and redeem inside YONO app"
    ]
  }
];

export default function WellnessCoach() {
  const [income, setIncome] = useState<number>(30000);
  const [savingsGoal, setSavingsGoal] = useState<number>(5000);
  const [rent, setRent] = useState<number>(8000);
  const [groceries, setGroceries] = useState<number>(6000);
  const [utilities, setUtilities] = useState<number>(4000);
  const [others, setOthers] = useState<number>(3000);

  // Compounding Calculator states
  const [selectedProduct, setSelectedProduct] = useState<string>("amrit-kalash");
  const [calcAmount, setCalcAmount] = useState<number>(10000);
  const [calcYears, setCalcYears] = useState<number>(3);
  const [goalAchieved, setGoalAchieved] = useState(false);

  // Calculations
  const totalExpenses = rent + groceries + utilities + others;
  const remainingCash = income - totalExpenses;
  const savingsEfficiency = income > 0 ? Math.round((remainingCash / income) * 100) : 0;

  // Real-time compound savings simulator
  const calculateMaturity = () => {
    const amount = Number(calcAmount) || 0;
    const years = Number(calcYears) || 1;
    
    if (selectedProduct === "amrit-kalash") {
      // 400 Days ~ 1.1 years, fixed rate 7.10%
      const r = 0.071;
      const n = 4; // compounded quarterly
      const maturityVal = amount * Math.pow(1 + r / n, n * 1.1);
      return Math.round(maturityVal);
    } else if (selectedProduct === "flexi-rd") {
      // Monthly RD. Let's assume amount is deposited monthly.
      // Formula: M = P * ((1 + i)^n - 1) / (1 - (1 + i)^-1/3) etc.
      // Simplified compound formula for regular monthly addition:
      const monthlyP = amount;
      const r = 0.068;
      const n = years * 12;
      const r_monthly = r / 12;
      let total = 0;
      for (let i = 0; i < n; i++) {
        total = (total + monthlyP) * (1 + r_monthly);
      }
      return Math.round(total);
    } else {
      // SIP (Equity Est) with ~12% compounding
      const monthlyP = amount;
      const r = 0.12;
      const n = years * 12;
      const r_monthly = r / 12;
      let total = 0;
      for (let i = 0; i < n; i++) {
        total = (total + monthlyP) * (1 + r_monthly);
      }
      return Math.round(total);
    }
  };

  const maturityValue = calculateMaturity();
  const totalInvested = selectedProduct === "amrit-kalash" ? calcAmount : calcAmount * calcYears * 12;
  const totalGain = maturityValue - totalInvested;

  return (
    <div id="wellness-coach" className="p-6 max-w-6xl mx-auto space-y-6">
      {/* Overview Banner */}
      <div className="bg-gradient-to-r from-indigo-900 to-violet-900 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden border border-indigo-800">
        <div className="absolute right-0 top-0 opacity-10 pointer-events-none transform translate-x-12 -translate-y-12">
          <TrendingUp size={300} />
        </div>
        <div className="max-w-2xl space-y-4">
          <span className="bg-indigo-500/30 text-indigo-200 text-xs font-bold tracking-widest uppercase px-3.5 py-1.5 rounded-full border border-indigo-400/20 inline-flex items-center gap-1.5">
            <Sparkles size={12} /> Wealth Intelligence Coach
          </span>
          <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">
            SBI Financial Wellness Hub
          </h1>
          <p className="text-indigo-100 text-sm md:text-base leading-relaxed">
            Optimize your budget, track savings targets, and discover top-performing SBI investment plans customized for your family's future.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Interactive Budgeting Dashboard (2 Columns) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-6 space-y-6">
            <h3 className="text-sm font-bold text-slate-900 tracking-tight">Monthly Pocket Budget Planner</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Sliders on Left */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="font-bold text-slate-700">Monthly Net Income (₹)</span>
                    <span className="font-bold text-indigo-600">₹{income.toLocaleString()}</span>
                  </div>
                  <input
                    id="slider-income"
                    type="range"
                    min={10000}
                    max={150000}
                    step={2000}
                    value={income}
                    onChange={(e) => setIncome(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="font-bold text-slate-700">Savings Target Goal (₹)</span>
                    <span className="font-bold text-indigo-600">₹{savingsGoal.toLocaleString()}</span>
                  </div>
                  <input
                    id="slider-goal"
                    type="range"
                    min={1000}
                    max={50000}
                    step={1000}
                    value={savingsGoal}
                    onChange={(e) => setSavingsGoal(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                  />
                </div>

                <div className="space-y-1.5 pt-2 border-t border-slate-50">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">Detailed Monthly Outflow (₹)</span>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="space-y-1">
                      <span className="text-slate-500">Rent & Housing</span>
                      <input
                        id="budget-rent"
                        type="number"
                        value={rent}
                        onChange={(e) => setRent(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-semibold text-slate-800"
                      />
                    </div>
                    <div className="space-y-1">
                      <span className="text-slate-500">Food & Groceries</span>
                      <input
                        id="budget-groceries"
                        type="number"
                        value={groceries}
                        onChange={(e) => setGroceries(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-semibold text-slate-800"
                      />
                    </div>
                    <div className="space-y-1">
                      <span className="text-slate-500">Utilities & Bills</span>
                      <input
                        id="budget-utilities"
                        type="number"
                        value={utilities}
                        onChange={(e) => setUtilities(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-semibold text-slate-800"
                      />
                    </div>
                    <div className="space-y-1">
                      <span className="text-slate-500">Entertainment/Others</span>
                      <input
                        id="budget-others"
                        type="number"
                        value={others}
                        onChange={(e) => setOthers(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-semibold text-slate-800"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Dynamic Chart Breakdown on Right */}
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100 flex flex-col justify-between">
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Smart Budget Summary</h4>
                  
                  <div className="space-y-2">
                    {/* Visual Bar Breakdown */}
                    <div className="h-4 w-full bg-slate-200 rounded-full overflow-hidden flex">
                      <div
                        className="bg-indigo-600 h-full"
                        style={{ width: `${Math.max(5, (rent / income) * 100)}%` }}
                        title="Rent"
                      />
                      <div
                        className="bg-sky-500 h-full"
                        style={{ width: `${Math.max(5, (groceries / income) * 100)}%` }}
                        title="Groceries"
                      />
                      <div
                        className="bg-emerald-500 h-full"
                        style={{ width: `${Math.max(5, (utilities / income) * 100)}%` }}
                        title="Utilities"
                      />
                      <div
                        className="bg-amber-500 h-full"
                        style={{ width: `${Math.max(5, (others / income) * 100)}%` }}
                        title="Others"
                      />
                      <div
                        className="bg-indigo-200 h-full flex-1"
                        title="Savings potential"
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-500 font-semibold pt-1">
                      <span className="flex items-center gap-1"><span className="w-2 h-2 bg-indigo-600 rounded-full inline-block"></span> Rent ({Math.round((rent/income)*100)}%)</span>
                      <span className="flex items-center gap-1"><span className="w-2 h-2 bg-sky-500 rounded-full inline-block"></span> Food ({Math.round((groceries/income)*100)}%)</span>
                      <span className="flex items-center gap-1"><span className="w-2 h-2 bg-emerald-500 rounded-full inline-block"></span> Bills ({Math.round((utilities/income)*100)}%)</span>
                      <span className="flex items-center gap-1"><span className="w-2 h-2 bg-indigo-200 rounded-full inline-block"></span> Potential Saving ({savingsEfficiency}%)</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-200/50 space-y-3">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500">Remaining Savings Potential:</span>
                    <span className={`font-bold text-sm ${remainingCash >= savingsGoal ? "text-emerald-600" : "text-amber-600"}`}>
                      ₹{remainingCash.toLocaleString()}
                    </span>
                  </div>

                  {remainingCash >= savingsGoal ? (
                    <div className="bg-emerald-50 text-emerald-800 text-[11px] p-3 rounded-xl border border-emerald-150 leading-relaxed font-medium flex items-start gap-2">
                      <CheckCircle2 size={16} className="text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <strong>Awesome budget!</strong> Your projected savings meet your goal. Lock these idle funds in high-performing SBI products.
                      </div>
                    </div>
                  ) : (
                    <div className="bg-amber-50 text-amber-800 text-[11px] p-3 rounded-xl border border-amber-150 leading-relaxed font-medium flex items-start gap-2">
                      <HelpCircle size={16} className="text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <strong>Action Needed:</strong> Reduce luxury/other expenses by ₹{(savingsGoal - remainingCash).toLocaleString()} to unlock your monthly savings goal.
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Calculator matched to products */}
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-6 space-y-6">
            <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <PiggyBank className="text-indigo-600" size={18} /> Interactive SBI Wealth Matching Calculator
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-700 block">Select SBI Investment vehicle</label>
                  <select
                    id="calc-product-select"
                    value={selectedProduct}
                    onChange={(e) => setSelectedProduct(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none text-slate-800 font-semibold"
                  >
                    <option value="amrit-kalash">SBI Amrit Kalash Scheme (Term Deposit - 7.10%)</option>
                    <option value="flexi-rd">SBI Flexi Recurring Deposit (Flexible RD - 6.80%)</option>
                    <option value="sip-mutual">SBI Mutual Fund SIP (Estimated compound - 12.0%)</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-700 block">
                    {selectedProduct === "amrit-kalash" ? "One-Time Deposit (₹)" : "Monthly Recurring Amount (₹)"}
                  </label>
                  <input
                    id="calc-amount-input"
                    type="number"
                    value={calcAmount}
                    onChange={(e) => setCalcAmount(Number(e.target.value))}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-800 outline-none"
                  />
                </div>

                {selectedProduct !== "amrit-kalash" && (
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-700 block">Investment Horizon (Tenure)</label>
                    <div className="grid grid-cols-3 gap-2">
                      {[1, 3, 5].map((y) => (
                        <button
                          key={y}
                          id={`btn-tenure-${y}`}
                          onClick={() => setCalcYears(y)}
                          className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                            calcYears === y
                              ? "bg-indigo-600 border-indigo-600 text-white shadow-sm"
                              : "bg-slate-50 hover:bg-slate-100 text-slate-600 border-slate-200"
                          }`}
                        >
                          {y} {y === 1 ? "Year" : "Years"}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Dynamic projections details */}
              <div className="bg-indigo-50/50 rounded-2xl p-5 border border-indigo-100 flex flex-col justify-between">
                <div className="space-y-3">
                  <span className="text-[10px] font-black tracking-widest uppercase text-indigo-700 block">Simulated Growth Blueprint</span>
                  
                  <div className="space-y-1">
                    <span className="text-xs text-slate-500 block">Projected Maturity Balance</span>
                    <span className="text-3xl font-black text-indigo-900">₹{maturityValue.toLocaleString()}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-2 text-xs text-slate-600 border-t border-indigo-100/50">
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase">Total Invested</span>
                      <span className="font-bold">₹{totalInvested.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase">Interest Earned</span>
                      <span className="font-bold text-emerald-600">+₹{totalGain.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4">
                  <a
                    href="https://www.onlinesbi.sbi"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-1"
                  >
                    Invest Instantly on SBI YONO <ArrowUpRight size={14} />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Product listing cards (1 Column) */}
        <div className="space-y-6">
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-6 space-y-4">
            <h3 className="text-xs font-extrabold uppercase tracking-widest text-slate-400">Recommended SBI Schemes</h3>
            
            <div className="space-y-4">
              {SBI_PRODUCTS.map((prod) => (
                <div
                  key={prod.id}
                  id={`prod-card-${prod.id}`}
                  onClick={() => {
                    setSelectedProduct(prod.id);
                    if (prod.id === "amrit-kalash") {
                      setCalcAmount(25000);
                    } else if (prod.id === "flexi-rd") {
                      setCalcAmount(1000);
                    } else {
                      setCalcAmount(500);
                    }
                  }}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer text-left ${
                    selectedProduct === prod.id
                      ? "bg-indigo-50 border-indigo-200 ring-2 ring-indigo-500/5"
                      : "bg-slate-50 hover:bg-slate-100 border-slate-100"
                  }`}
                >
                  <div className="flex justify-between items-start mb-1">
                    <span className="text-xs font-black text-indigo-900 tracking-tight">{prod.name}</span>
                    <span className="bg-indigo-100 text-indigo-800 text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                      {prod.interestRate}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-relaxed mb-3">{prod.description}</p>
                  
                  <ul className="space-y-1 text-[10px] text-slate-600 font-medium">
                    {prod.benefits.map((b, idx) => (
                      <li key={idx} className="flex gap-1.5 items-start">
                        <Award size={12} className="text-emerald-500 shrink-0 mt-0.5" />
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
